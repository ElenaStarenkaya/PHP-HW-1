<?php

echo $header;
echo $posts;
echo $gallery;
echo $features;
echo $contact_form;
echo $footer;
echo $scripts;