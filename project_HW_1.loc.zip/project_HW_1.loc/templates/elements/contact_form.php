<div class="wrapper">
            <div class="forms">
                <h2>Write to us</h2>
                <form action="/search" method="POST">
                    <ul>
                        <li>
                            <legend><strong>Name: </strong></legend>
                            <input type="text" name="" id="" placeholder="">
                        </li>
                        <li>
                            <legend><strong>E-mail: </strong></legend>
                            <input type="email" name="" id="" placeholder="">
                        </li>
                        <li>
                            <legend><strong>Phone: </strong></legend>
                            <input type="email" name="" id="" placeholder="">
                        </li>
                    </ul>
            </div>
            <div class="contact">
                <legend><strong>Contact me via: </strong></legend>

                <label for="method1">E-mail:</label>
                <input type="radio" name="select" id="method1">

                <label for="method2">Phone:</label>
                <input type="radio" name="select" id="method2">

                <label for="method3">Telegram:</label>
                <input type="radio" name="select" id="method3">
            </div>

            <div class="list">
                <legend><strong>Topic: </strong></legend>
                <input type="text" list="lst" placeholder="Post my story">
                <datalist id="lst">
                    <option value="Empty"></option>
                    <option value="Empty"></option>
                    <option value="Empty"></option>
                    <option value="Empty"></option>
                    <option value="Empty"></option>
                </datalist>
            </div>

            <div class="textarea">
                <legend><strong>Message: </strong></legend>
                <label for="umeasge"></label>
                <textarea name="userMessage" id="umeasge"></textarea>
            </div>

            <div class="checkbox">
                <legend>I am a human </legend>
                <input type="checkbox" name="news" id="news">
            </div>
            <div>
                <button class="btn_1">SEND</button>
            </div>
            </form>

            
        </div>