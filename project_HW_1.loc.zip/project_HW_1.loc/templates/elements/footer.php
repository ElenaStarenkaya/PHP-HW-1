<div class="wrapper">
    <br>

            <hr>

            <footer class="footer">
                <ul class="social-icons-2">
                    <li class="social-icon tw"><a href="http://www.twitter.com"><img src="img/twitter-128.png"
                                style="height: 24px; width: 24px;" /></a></li>
                    <li class="social-icon fb"><a href="http://www.facebook.com"><img src="img/facebook-128.png"
                                style="height: 24px; width: 24px;" /></a></li>
                    <li class="social-icon inst"><a href="http://www.instagram.com"><img src="img/instagram-2-128.png"
                                style="height: 24px; width: 24px;" /></a></li>
                    <li class="social-icon you"><a href="http://www.youtube.com"><img src="img/youtube-128.png"
                                style="height: 24px; width: 24px;" /></a></li>
                    <li class="social-icon gml"><a href="http://www.gmail.com"><img src="img/gmail-128.png"
                                style="height: 24px; width: 24px;" /></a>
                    </li>
                </ul>
                <div class="footer_text">©UNTITELED 2019</div>
            </footer>
</div>