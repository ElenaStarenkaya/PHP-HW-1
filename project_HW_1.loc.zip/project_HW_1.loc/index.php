<?php

include('./functions.php');
include('./data.php');

// $posts = [
//     ['title' => 'post one', 'slug' => 'slug one', 'img' => 'img/pic1.jpg'],
//     ['title' => 'post two', 'slug' => 'slug two', 'img' => 'img/pic2.jpg'],
//     ['title' => 'post new', 'slug' => 'slug new', 'img' => 'img/pic3.jpg'],
//     ['title' => 'post last', 'slug' => 'slug last', 'img' => 'img/pic4.jpg']
// ]; 

$posts_tmp = get_template('./templates/elements/post_list.php', ['posts' => $posts]);

$elements_tmp = [
    'header' => get_template('./templates/elements/header.php'),
    'posts' => $posts_tmp,
    'gallery' => get_template('./templates/elements/gallery.php'),
    'features' => get_template('./templates/elements/features.php'),
    'contact_form' => get_template('./templates/elements/contact_form.php'),
    'footer' => get_template('./templates/elements/footer.php'),
    'scripts' => get_template('./templates/elements/scripts.php'),
];

$page_tmp = get_template('./templates/pages/home.php', $elements_tmp);

$layout_tmp = get_template('./templates/layouts/main.php', ['page' => $page_tmp]);

echo $layout_tmp; 